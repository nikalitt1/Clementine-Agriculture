import rclpy
from rclpy.node import Node
import numpy as np
import cv2
import time

from std_msgs.msg import Float32MultiArray
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from filterpy.kalman import KalmanFilter


class KalmanTrackerNode(Node):
    def __init__(self):
        super().__init__('kalman_tracker_node')

        # Subscriptions
        self.subscription = self.create_subscription(
            Float32MultiArray,
            'zed/mockweed_centers_depth',
            self.detection_callback,
            10
        )
        self.image_sub = self.create_subscription(
            Image,
            'zed/image_raw',
            self.image_callback,
            10
        )

        # Publishers
        self.predicted_pub = self.create_publisher(Image, 'zed/image_predicted', 10)
        self.predicted_coords_pub = self.create_publisher(Float32MultiArray, 'zed/mockweed_predicted_coords', 10)

        self.bridge = CvBridge()
        self.latest_frame = None
        self.latest_detections = []  # store current detections for display

        # Kalman tracking storage
        self.kalman_filters = {}   # tid -> KalmanFilter
        self.track_last_seen = {}  # tid -> timestamp
        self.next_track_id = 0
        self.track_ttl = 0.5
        self.prediction_horizon = 0.5  # seconds into future
        self.dt = 0.033  # time step for Kalman filter

        # Trail history (for drawing past predicted positions)
        self.trails = {}  # tid -> list of (x, y)
        self.smoothing_factor = 0.3  # EMA alpha for smoothing
        self.max_trail_length = 20

        # Timer: publish predictions continuously
        self.pub_timer = self.create_timer(1.0 / 15.0, self.publish_predictions)

    def create_kalman_filter(self, u, v):
        dt = self.dt
        kf = KalmanFilter(dim_x=6, dim_z=2)
        kf.F = np.array([
            [1,0,dt,0,0.5*dt*dt,0],
            [0,1,0,dt,0,0.5*dt*dt],
            [0,0,1,0,dt,0],
            [0,0,0,1,0,dt],
            [0,0,0,0,1,0],
            [0,0,0,0,0,1],
        ], dtype=float)
        kf.H = np.array([[1,0,0,0,0,0],
                         [0,1,0,0,0,0]], dtype=float)
        kf.R *= 10.0
        kf.P *= 500.0
        kf.Q = np.eye(6) * 0.1

        # Initialize state with measurement
        kf.x = np.array([[u], [v], [0.0], [0.0], [0.0], [0.0]], dtype=float)
        return kf

    def detection_callback(self, msg: Float32MultiArray):
        # store detections for display
        self.latest_detections = [(msg.data[i], msg.data[i+1]) for i in range(0, len(msg.data), 2)]

        now = time.time()

        # Predict current tracks
        for kf in self.kalman_filters.values():
            kf.predict()

        unmatched_dets = set(range(len(self.latest_detections)))
        unmatched_tracks = set(self.kalman_filters.keys())
        track_positions = {tid: (kf.x[0, 0], kf.x[1, 0]) for tid, kf in self.kalman_filters.items()}

        # Match detections to tracks
        for di, det in enumerate(self.latest_detections):
            du, dv = det
            if not unmatched_tracks:
                break
            best_tid = None
            best_dist = float('inf')
            for tid in list(unmatched_tracks):
                tx, ty = track_positions[tid]
                dist = np.hypot(tx - du, ty - dv)
                if dist < best_dist:
                    best_dist = dist
                    best_tid = tid
            if best_tid is not None and best_dist < 50:
                kf = self.kalman_filters[best_tid]
                kf.update(np.array([du, dv], dtype=float))
                self.track_last_seen[best_tid] = now
                unmatched_tracks.discard(best_tid)
                unmatched_dets.discard(di)

        # Start new tracks
        for di in unmatched_dets:
            du, dv = self.latest_detections[di]
            kf = self.create_kalman_filter(du, dv)
            tid = self.next_track_id
            self.next_track_id += 1
            self.kalman_filters[tid] = kf
            self.track_last_seen[tid] = now
            self.trails[tid] = []

        # Remove stale tracks
        stale_ids = [tid for tid, tlast in self.track_last_seen.items() if now - tlast > self.track_ttl]
        for tid in stale_ids:
            self.kalman_filters.pop(tid, None)
            self.track_last_seen.pop(tid, None)
            self.trails.pop(tid, None)

    def image_callback(self, msg: Image):
        try:
            self.latest_frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f"Image conversion failed: {e}")

    def publish_predictions(self):
        if self.latest_frame is None:
            return

        frame = self.latest_frame.copy()
        t = self.prediction_horizon

        predicted_coords = Float32MultiArray()
        predicted_data = []

        # Draw predicted future positions and trails
        for tid, kf in self.kalman_filters.items():
            u, v = float(kf.x[0, 0]), float(kf.x[1, 0])
            u_dot, v_dot = float(kf.x[2, 0]), float(kf.x[3, 0])
            u_dd, v_dd = float(kf.x[4, 0]), float(kf.x[5, 0])

            # Predict t seconds into the future
            pred_u = u + u_dot * t + 0.5 * u_dd * t * t
            pred_v = v + v_dot * t + 0.5 * v_dd * t * t

            # Smooth with EMA
            if self.trails[tid]:
                last_u, last_v = self.trails[tid][-1]
                pred_u = self.smoothing_factor * pred_u + (1 - self.smoothing_factor) * last_u
                pred_v = self.smoothing_factor * pred_v + (1 - self.smoothing_factor) * last_v

            # Save predicted position for publishing
            predicted_data.extend([float(pred_u), float(pred_v)])

            # Update trail
            self.trails[tid].append((int(pred_u), int(pred_v)))
            if len(self.trails[tid]) > self.max_trail_length:
                self.trails[tid].pop(0)

            # Draw fading trail
            trail_len = len(self.trails[tid])
            for i in range(1, trail_len):
                alpha = i / trail_len
                color = (0, 0, int(255 * alpha))  # red fading
                cv2.line(frame, self.trails[tid][i-1], self.trails[tid][i], color, 2)

            # Draw predicted crosshair
            cv2.drawMarker(
                frame,
                (int(pred_u), int(pred_v)),
                (0, 0, 255),  # bright red
                markerType=cv2.MARKER_CROSS,
                markerSize=20,
                thickness=2
            )

        # Draw current detections as small green circles
        for det in self.latest_detections:
            cx, cy = int(det[0]), int(det[1])
            cv2.circle(frame, (cx, cy), 4, (0, 255, 0), -1)

        # Publish predicted coordinates
        predicted_coords.data = predicted_data
        self.predicted_coords_pub.publish(predicted_coords)

        # Publish frame
        msg = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
        self.predicted_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = KalmanTrackerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
