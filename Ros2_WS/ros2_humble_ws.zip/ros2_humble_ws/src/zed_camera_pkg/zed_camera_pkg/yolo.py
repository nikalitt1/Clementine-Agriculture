import rclpy
from rclpy.node import Node
import cv2
import math
import numpy as np

from std_msgs.msg import Float32MultiArray, Float32
from geometry_msgs.msg import Vector3
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from ultralytics import YOLO
import pyzed.sl as sl


class ZEDCameraNode(Node):
    def __init__(self):
        super().__init__('zed_yolo_node')

        # Publishers
        self.image_pub = self.create_publisher(Image, 'zed/image_raw', 10)
        self.mockweed_depth_pub = self.create_publisher(Float32MultiArray, 'zed/weed_centers', 10)
        self.depth_pub = self.create_publisher(Float32, 'zed/depth', 10)
        self.orientation_pub = self.create_publisher(Vector3, 'zed/orientation', 10)

        self.bridge = CvBridge()
        model_path = "/home/nika/belt.engine"
        self.model = YOLO(model_path)
        self.class_names = ["crop", "weed"]

        # Init ZED
        self.zed = sl.Camera()
        init_params = sl.InitParameters()
        init_params.camera_resolution = sl.RESOLUTION.HD1080
        init_params.depth_mode = sl.DEPTH_MODE.PERFORMANCE
        init_params.coordinate_units = sl.UNIT.METER
        init_params.camera_fps = 30

        status = self.zed.open(init_params)
        if status != sl.ERROR_CODE.SUCCESS:
            self.get_logger().error(f"ZED failed to open: {status}")
            return
        self.camera_ready = True

        tracking_params = sl.PositionalTrackingParameters()
        self.zed.enable_positional_tracking(tracking_params)

        self.runtime_params = sl.RuntimeParameters()
        self.image = sl.Mat()
        self.depth = sl.Mat()
        self.pose = sl.Pose()

        self.timer = self.create_timer(1.0 / 30.0, self.capture_callback)

    def capture_callback(self):
        if self.zed.grab(self.runtime_params) != sl.ERROR_CODE.SUCCESS:
            return

        # Retrieve image and depth
        self.zed.retrieve_image(self.image, sl.VIEW.LEFT)
        self.zed.retrieve_measure(self.depth, sl.MEASURE.DEPTH)
        self.zed.get_position(self.pose, sl.REFERENCE_FRAME.WORLD)

        frame = self.image.get_data()
        frame_small = cv2.resize(frame, (640, 360))
        frame_bgr = cv2.cvtColor(frame_small, cv2.COLOR_BGRA2BGR)

        # YOLO inference
        results = self.model.predict(source=frame_bgr, imgsz=640, verbose=False)
        detections = []

        for result in results:
            boxes = result.boxes.xyxy.cpu().numpy()
            confs = result.boxes.conf.cpu().numpy()
            classes = result.boxes.cls.cpu().numpy()
            for box, conf, cls_id in zip(boxes, confs, classes):
                if conf < 0.25 or self.class_names[int(cls_id)] != "weed":
                    continue
                x1, y1, x2, y2 = map(int, box)
                cx = (x1 + x2) // 2
                cy = (y1 + y2) // 2
                detections.append((cx, cy))

                # Draw for debug
                cv2.drawMarker(
                    frame_bgr,
                    (cx, cy),
                    (0, 0, 255),            # Red color in BGR
                    markerType=cv2.MARKER_CROSS,
                    markerSize=10,           # size of the crosshair
                    thickness=2
                )

        # Publish raw image
        try:
            msg = self.bridge.cv2_to_imgmsg(frame_bgr, encoding='bgr8')
            self.image_pub.publish(msg)
        except Exception as e:
            self.get_logger().error(f"Failed to publish image: {e}")

        # Publish detections (pixel coords only)
        if detections:
            msg = Float32MultiArray()
            flat = []
            for cx, cy in detections:
                flat.extend([float(cx), float(cy)])
            msg.data = flat
            self.mockweed_depth_pub.publish(msg)

        # --- Publish average depth of frame ---
        depth_data = self.depth.get_data()  # numpy array (H, W)
        if depth_data is not None:
            valid_depths = depth_data[np.isfinite(depth_data)]
            if valid_depths.size > 0:
                avg_depth = np.mean(valid_depths)
                self.depth_pub.publish(Float32(data=round(avg_depth * 1000, 0)))  # in mm

        # --- Publish orientation (yaw, pitch, roll) ---
        rotation = self.pose.get_euler_angles()
        pitch = math.degrees(rotation[1])
        roll = math.degrees(rotation[2])
        yaw = math.degrees(rotation[0])
        orientation_msg = Vector3(x=yaw, y=pitch, z=roll)
        self.orientation_pub.publish(orientation_msg)


def main(args=None):
    rclpy.init(args=args)
    node = ZEDCameraNode()
    if not getattr(node, 'camera_ready', False):
        node.destroy_node()
        rclpy.shutdown()
        return
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
