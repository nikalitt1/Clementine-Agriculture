from setuptools import setup

package_name = 'zed_camera_pkg'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    install_requires=[
        'setuptools',
        'opencv-python',
        'numpy',
        'pyzed',
        'ultralytics',
        'cv_bridge',
        'flask',
        'threading',
    ],
    entry_points={
        'console_scripts': [
            'yolo_node = zed_camera_pkg.yolo:main',
            'velocity_node = zed_camera_pkg.velocity:main',
            'stream_node = zed_camera_pkg.stream:main',
        ],
    },
)

