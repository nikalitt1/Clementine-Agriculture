import rclpy
from rclpy.node import Node
import serial
import time
from threading import Thread, Lock
import joblib
import pandas as pd
import numpy as np
from smbus2 import SMBus

from std_msgs.msg import Float32MultiArray, Float32
from geometry_msgs.msg import Vector3

# ========================
# PCA9685 Laser Control
# ========================
PCA9685_ADDRESS = 0x40
MODE1 = 0x00
MODE2 = 0x01
LED0_ON_L = 0x06
LED0_ON_H = 0x07
LED0_OFF_L = 0x08
LED0_OFF_H = 0x09
I2C_BUS_NUMBER = 7

LASER_POWER = 0.3       # duty cycle
LASER_PULSE_DURATION = 0.5
LASER_ON_DELAY = 0.2    # delay before turning on after arm settles

def init_pca9685(bus):
    bus.write_byte_data(PCA9685_ADDRESS, MODE1, 0x00)
    bus.write_byte_data(PCA9685_ADDRESS, MODE2, 0x04)
    time.sleep(0.1)

def set_pwm(bus, channel, pulse_width):
    on_time = 0
    off_time = int(pulse_width)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_ON_L + 4 * channel, on_time & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_ON_H + 4 * channel, (on_time >> 8) & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_OFF_L + 4 * channel, off_time & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_OFF_H + 4 * channel, (off_time >> 8) & 0xFF)

def set_duty_cycle(bus, channel, percent):
    percent = max(0, min(100, percent))
    ticks = int(percent * 4095 / 100)
    set_pwm(bus, channel, ticks)

def fire_laser(bus, channel, power=LASER_POWER, pulse_duration=LASER_PULSE_DURATION, delay=LASER_ON_DELAY):
    """Fire laser once after a short delay."""
    time.sleep(delay)
    set_duty_cycle(bus, channel, power)  
    time.sleep(pulse_duration)
    set_duty_cycle(bus, channel, 0.0)

# ========================
# Servo Control
# ========================
def checksum(data):
    return (~sum(data)) & 0xFF

def sync_write_positions(ser, positions, debug=False):
    if not positions:
        return
    data = []
    for sid, deg in positions.items():
        pos_val = int((deg / 360.0) * 4095)
        pos_val = max(0, min(4095, pos_val))
        pos_l = pos_val & 0xFF
        pos_h = (pos_val >> 8) & 0xFF
        data.extend([sid, pos_l, pos_h, 0x00, 0x00])

    length = len(data) + 4
    packet = [0xFF, 0xFF, 0xFE, length, 0x83, 0x2A, 0x04] + data
    packet.append(checksum(packet[2:]))
    ser.write(bytearray(packet))
    if debug:
        print("[SYNC_WRITE]", packet)

# ========================
# ROS2 Node
# ========================
class AllArmsNode(Node):
    def __init__(self):
        super().__init__('all_arms_node')

        # Serial setup
        self.ports_servos = {
            '/dev/ttyUSB1': [1, 2, 5, 6],
            '/dev/ttyUSB0': [3, 4, 7, 8]
        }
        self.ser_ports = {}
        baud = 1000000
        for port, ids in self.ports_servos.items():
            try:
                self.ser_ports[port] = serial.Serial(port, baudrate=baud, timeout=0.1)
                self.get_logger().info(f"Opened {port} for servos {ids}")
            except Exception as e:
                self.get_logger().error(f"Failed to open {port}: {e}")

        # Servo ID mapping
        self.servo_pairs = {
            "arm1": (5, 1),
            "arm2": (6, 2),
            "arm3": (8, 3),
            "arm4": (7, 4)
        }

        # Load models
        self.models = {arm: joblib.load(f"/home/nika/RF_Fine_{arm.capitalize()}.pkl") for arm in self.servo_pairs}

        # Load action spaces
        self.action_spaces = {}
        for arm in self.models:
            csv_path = f"/home/nika/RF_Fine_{arm.capitalize()}_cleaned.csv"
            try:
                df = pd.read_csv(csv_path)
                u_min, u_max = df["Pixel_X"].min(), df["Pixel_X"].max()
                v_min, v_max = df["Pixel_Y"].min(), df["Pixel_Y"].max()
                self.action_spaces[arm] = (u_min, u_max, v_min, v_max)
            except Exception as e:
                self.get_logger().error(f"Could not load {csv_path}: {e}")

        self.get_logger().info(f"Action spaces: {self.action_spaces}")

        # Laser setup
        self.bus = SMBus(I2C_BUS_NUMBER)
        init_pca9685(self.bus)
        self.arm_lasers = {arm: [i+1] for i, arm in enumerate(self.models)}

        # State variables
        self.latest_weeds = []
        self.latest_depth = None
        self.latest_pitch = None
        self.latest_roll = None
        self.last_positions = {}
        self.arm_state = {arm: 'idle' for arm in self.models}
        self.arm_target = {arm: None for arm in self.models}
        self.settle_threshold = 2.0
        self.lock = Lock()
        self.debug_packets = True

        # YOLO 640x360 -> 1920x1080 scaling
        self.scale_x = 1920 / 640
        self.scale_y = 1080 / 360

        # Update flag must be set **before** starting the thread
        self.update_flag = False

        # Background movement thread
        self.worker_thread = Thread(target=self.movement_loop, daemon=True)
        self.worker_thread.start()

        # ROS2 subscriptions
        self.create_subscription(Float32MultiArray, 'zed/predicted_centers', self.weed_callback, 10)
        self.create_subscription(Float32, 'zed/depth', self.depth_callback, 10)
        self.create_subscription(Vector3, 'zed/orientation', self.orientation_callback, 10)

        self.get_logger().info("All-arms control node started.")

    # ========================
    # ROS2 Callbacks
    # ========================
    def weed_callback(self, msg):
        if len(msg.data) % 2 != 0:
            self.get_logger().warn("Weed data malformed.")
            return
        with self.lock:
            self.latest_weeds = [(u*self.scale_x, v*self.scale_y) for u,v in zip(msg.data[::2], msg.data[1::2])]
            self.update_flag = True

    def depth_callback(self, msg):
        with self.lock:
            self.latest_depth = msg.data
            self.update_flag = True

    def orientation_callback(self, msg):
        with self.lock:
            self.latest_pitch = msg.x
            self.latest_roll = msg.y
            self.update_flag = True

    # ========================
    # Background movement loop
    # ========================
    def movement_loop(self):
        while rclpy.ok():
            if not self.update_flag:
                time.sleep(0.001)
                continue
            with self.lock:
                self.update_flag = False
                weeds = list(self.latest_weeds)
                depth = self.latest_depth
                pitch = self.latest_pitch
                roll = self.latest_roll
            self.try_move(weeds, depth, pitch, roll)

    # ========================
    # Compute servo commands
    # ========================
    def try_move(self, weeds, depth, pitch, roll):
        if None in (depth, pitch, roll):
            return

        positions = {}
        active_arms = []

        for arm, model in self.models.items():
            u_min, u_max, v_min, v_max = self.action_spaces[arm]
            u_center = (u_min + u_max) / 2
            v_center = (v_min + v_max) / 2

            weeds_in_range = [(u,v) for u,v in weeds if u_min <= u <= u_max and v_min <= v <= v_max]

            if weeds_in_range:
                u_target, v_target = min(weeds_in_range, key=lambda w: (w[0]-u_center)**2 + (w[1]-v_center)**2)
                self.arm_target[arm] = (u_target, v_target)
                if self.arm_state[arm] == 'idle':
                    self.arm_state[arm] = 'aiming'
            else:
                self.arm_target[arm] = None
                self.arm_state[arm] = 'idle'

            if self.arm_target[arm]:
                u_target, v_target = self.arm_target[arm]
                depth_safe = 0.26 if depth is None or np.isnan(depth) else depth
                features = [[u_target, v_target, depth_safe, pitch, roll]]
                theta_x, theta_y = model.predict(features)[0]
                sid_x, sid_y = self.servo_pairs[arm]
                positions[sid_x] = theta_x
                positions[sid_y] = theta_y
                active_arms.append(arm)

        # Send servo commands in parallel
        threads = []
        for port, sids in self.ports_servos.items():
            port_positions = {sid: positions[sid] for sid in sids if sid in positions}
            if port_positions:
                t = Thread(target=sync_write_positions, args=(self.ser_ports[port], port_positions, self.debug_packets))
                t.start()
                threads.append(t)
        for t in threads:
            t.join()

        # Fire lasers when arm is settled
        for arm in active_arms:
            sid_x, sid_y = self.servo_pairs[arm]
            x_ok = abs(self.last_positions.get(sid_x, 0) - positions[sid_x]) < self.settle_threshold
            y_ok = abs(self.last_positions.get(sid_y, 0) - positions[sid_y]) < self.settle_threshold

            if self.arm_state[arm] == 'aiming' and x_ok and y_ok:
                self.arm_state[arm] = 'fired'
                for ch in self.arm_lasers[arm]:
                    Thread(target=fire_laser, args=(self.bus, ch)).start()

            self.last_positions[sid_x] = positions[sid_x]
            self.last_positions[sid_y] = positions[sid_y]

        # Reset fired state if target disappears
        for arm in self.models:
            if self.arm_state[arm] == 'fired' and self.arm_target[arm] is None:
                self.arm_state[arm] = 'idle'

        self.get_logger().info(f"Weeds: {weeds}, Arm states: {self.arm_state}")

# ========================
# Entry point
# ========================
def main(args=None):
    rclpy.init(args=args)
    node = AllArmsNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        for ch in range(1, 5):
            set_duty_cycle(node.bus, ch, 0.0)
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

