import rclpy
from rclpy.node import Node
import serial
import time
from threading import Thread, Lock
import joblib
import pandas as pd
import numpy as np
from smbus2 import SMBus
from std_msgs.msg import Float32MultiArray, Float32
from geometry_msgs.msg import Vector3
from collections import deque

# ========================
# PCA9685 Laser Control
# ========================
PCA9685_ADDRESS = 0x40
MODE1 = 0x00
MODE2 = 0x01
LED0_ON_L = 0x06
LED0_ON_H = 0x07
LED0_OFF_L = 0x08
LED0_OFF_H = 0x09
I2C_BUS_NUMBER = 7
LASER_POWER = 1.0  # % duty cycle

def init_pca9685(bus):
    bus.write_byte_data(PCA9685_ADDRESS, MODE1, 0x00)
    bus.write_byte_data(PCA9685_ADDRESS, MODE2, 0x04)

def set_pwm(bus, channel, pulse_width):
    on_time = 0
    off_time = int(pulse_width)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_ON_L + 4 * channel, on_time & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_ON_H + 4 * channel, (on_time >> 8) & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_OFF_L + 4 * channel, off_time & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_OFF_H + 4 * channel, (off_time >> 8) & 0xFF)

def set_duty_cycle(bus, channel, percent):
    percent = max(0, min(100, percent))
    ticks = int(percent * 4095 / 100)
    set_pwm(bus, channel, ticks)

class LaserController:
    """Thread-safe laser control."""
    def __init__(self, bus):
        self.bus = bus
        self.laser_states = {}
        self.lock = Lock()

    def turn_on(self, channel):
        with self.lock:
            if not self.laser_states.get(channel, False):
                set_duty_cycle(self.bus, channel, LASER_POWER)
                self.laser_states[channel] = True

    def turn_off(self, channel):
        with self.lock:
            if self.laser_states.get(channel, False):
                set_duty_cycle(self.bus, channel, 0.0)
                self.laser_states[channel] = False

# ========================
# Servo Control
# ========================
def checksum(data):
    return (~sum(data)) & 0xFF

def sync_write_positions(ser, positions, debug=False):
    if not positions:
        return
    data = []
    for sid, deg in positions.items():
        pos_val = int((deg / 360.0) * 4095)
        pos_val = max(0, min(4095, pos_val))
        pos_l = pos_val & 0xFF
        pos_h = (pos_val >> 8) & 0xFF
        speed = 0x03FF
        speed_l = speed & 0xFF
        speed_h = (speed >> 8) & 0xFF
        data.extend([sid, pos_l, pos_h, speed_l, speed_h])
    length = len(data) + 4
    packet = [0xFF, 0xFF, 0xFE, length, 0x83, 0x2A, 0x04] + data
    packet.append(checksum(packet[2:]))
    ser.write(bytearray(packet))
    if debug:
        print("[SYNC_WRITE]", packet)
        for sid in positions:
            print(f"[DEBUG] Servo {sid} target: {positions[sid]}")

# ========================
# ROS2 Node
# ========================
class AllArmsNode(Node):
    def __init__(self):
        super().__init__('all_arms_node')

        # Serial setup
        self.ports_servos = {
            '/dev/ttyUSB1': [1, 2, 5, 6],
            '/dev/ttyUSB0': [3, 4, 7, 8]
        }
        self.ser_ports = {}
        baud = 1000000
        for port, ids in self.ports_servos.items():
            try:
                self.ser_ports[port] = serial.Serial(port, baudrate=baud, timeout=0.1)
                self.get_logger().info(f"Opened {port} for servos {ids}")
            except Exception as e:
                self.get_logger().error(f"Failed to open {port}: {e}")

        self.servo_pairs = {
            "arm1": (5, 1),
            "arm2": (6, 2),
            "arm3": (8, 3),
            "arm4": (7, 4)
        }

        # Manual X/Y offsets
        self.x_offsets = { "arm1": 0.0, "arm2": 3.0, "arm3": 3.0, "arm4": 0.0 }
        self.y_offsets = { "arm1": 0.0, "arm2": 2.0, "arm3": 6.0, "arm4": 6.0 }

        # Load models
        self.models = {arm: joblib.load(f"/home/nika/RF_Fine_{arm.capitalize()}.pkl") for arm in self.servo_pairs}

        # Load action spaces
        self.action_spaces = {}
        csv_files = {
            "arm1": "/home/nika/RF_Fine_Arm1_cleaned.csv",
            "arm2": "/home/nika/RF_Fine_Arm3_cleaned.csv",
            "arm3": "/home/nika/RF_Fine_Arm3_cleaned.csv",
            "arm4": "/home/nika/RF_Fine_Arm4_cleaned.csv"
        }
        for arm, path in csv_files.items():
            try:
                df = pd.read_csv(path)
                self.action_spaces[arm] = (df["Pixel_X"].min(), df["Pixel_X"].max(),
                                           df["Pixel_Y"].min(), df["Pixel_Y"].max())
            except:
                self.action_spaces[arm] = (0,0,0,0)

        # Laser setup
        self.bus = SMBus(I2C_BUS_NUMBER)
        init_pca9685(self.bus)
        self.arm_lasers = {arm: [i+1] for i, arm in enumerate(self.models)}
        self.laser_ctrl = LaserController(self.bus)

        # State variables
        self.latest_weeds = []
        self.latest_depth = None
        self.latest_pitch = None
        self.latest_roll = None
        self.lock = Lock()
        self.update_flag = False
        self.last_positions = {}

        # Scaling
        self.scale_x = 1920/640
        self.scale_y = 1080/360

        self.servo_queues = {port: deque(maxlen=1) for port in self.ports_servos}

        # Start threads
        for port in self.ports_servos:
            Thread(target=self.servo_port_loop, args=(port,), daemon=True).start()
        Thread(target=self.movement_loop, daemon=True).start()

        # Subscriptions
        self.create_subscription(Float32MultiArray, 'zed/predicted_centers', self.weed_callback, 10)
        self.create_subscription(Float32, 'zed/depth', self.depth_callback, 10)
        self.create_subscription(Vector3, 'zed/orientation', self.orientation_callback, 10)

        self.get_logger().info("All-arms control node started.")

    # ========================
    # Callbacks
    # ========================
    def weed_callback(self, msg):
        if len(msg.data) % 3 != 0:
            return
        with self.lock:
            self.latest_weeds = [(int(msg.data[i]), msg.data[i+1]*self.scale_x, msg.data[i+2]*self.scale_y)
                                 for i in range(0,len(msg.data),3)]
            self.update_flag = True

    def depth_callback(self, msg):
        with self.lock:
            self.latest_depth = msg.data
            self.update_flag = True

    def orientation_callback(self, msg):
        with self.lock:
            self.latest_pitch = msg.x
            self.latest_roll = msg.y
            self.update_flag = True

    # ========================
    # Loops
    # ========================
    def movement_loop(self):
        while rclpy.ok():
            if not self.update_flag:
                time.sleep(0.001)
                continue
            with self.lock:
                self.update_flag = False
                weeds = list(self.latest_weeds)
                depth = self.latest_depth
                pitch = self.latest_pitch
                roll = self.latest_roll
            self.try_move(weeds, depth, pitch, roll)

    def servo_port_loop(self, port):
        ser = self.ser_ports[port]
        queue = self.servo_queues[port]
        while rclpy.ok():
            if queue:
                positions = queue.pop()
                queue.clear()
                sync_write_positions(ser, positions, True)
            else:
                time.sleep(0.001)

    # ========================
    # Updated try_move with single tolerance
    # ========================
    def try_move(self, weeds, depth, pitch, roll):
        if None in (depth, pitch, roll):
            return

        positions = {}
        tol = 10.0  # single tolerance for firing

        for arm, model in self.models.items():
            u_min, u_max, v_min, v_max = self.action_spaces[arm]
            weeds_in_range = [(wid,u,v) for wid,u,v in weeds if u_min <= u <= u_max and v_min <= v <= v_max]

            sid_x, sid_y = self.servo_pairs[arm]
            current_x = self.last_positions.get(sid_x, 0.0)
            current_y = self.last_positions.get(sid_y, 0.0)

            if not weeds_in_range:
                for ch in self.arm_lasers[arm]:
                    self.laser_ctrl.turn_off(ch)
                continue

            # pick closest target
            best_target = min(weeds_in_range,
                              key=lambda w: (w[1]-current_x)**2 + (w[2]-current_y)**2)
            wid, u_target, v_target = best_target

            theta_x, theta_y = model.predict([[u_target, v_target, depth, pitch, roll]])[0]
            theta_x += self.x_offsets.get(arm,0.0)
            theta_y += self.y_offsets.get(arm,0.0)

            positions[sid_x] = round(theta_x,2)
            positions[sid_y] = round(theta_y,2)

            # fire laser if within tolerance
            dx = abs(theta_x - current_x)
            dy = abs(theta_y - current_y)
            for ch in self.arm_lasers[arm]:
                if dx <= tol and dy <= tol:
                    self.laser_ctrl.turn_on(ch)
                else:
                    self.laser_ctrl.turn_off(ch)

        # send positions
        for port, sids in self.ports_servos.items():
            port_positions = {sid: positions[sid] for sid in sids if sid in positions}
            if port_positions:
                self.servo_queues[port].append(port_positions)

        self.last_positions.update(positions)

# ========================
# Entry point
# ========================
def main(args=None):
    rclpy.init(args=args)
    node = AllArmsNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        for lasers in node.arm_lasers.values():
            for ch in lasers:
                node.laser_ctrl.turn_off(ch)
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

