import rclpy
from rclpy.node import Node
import serial
import struct
from smbus2 import SMBus
import joblib
import time
import glob

from std_msgs.msg import Float32MultiArray, Float32
from geometry_msgs.msg import Vector3

# ========================
# PCA9685 Laser Control
# ========================
PCA9685_ADDRESS = 0x40
MODE1 = 0x00
MODE2 = 0x01
LED0_ON_L = 0x06
LED0_ON_H = 0x07
LED0_OFF_L = 0x08
LED0_OFF_H = 0x09

I2C_BUS_NUMBER = 7

def init_pca9685(bus):
    bus.write_byte_data(PCA9685_ADDRESS, MODE1, 0x00)
    bus.write_byte_data(PCA9685_ADDRESS, MODE2, 0x04)
    time.sleep(0.1)

def set_pwm(bus, channel, pulse_width):
    on_time = 0
    off_time = int(pulse_width)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_ON_L + 4 * channel, on_time & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_ON_H + 4 * channel, (on_time >> 8) & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_OFF_L + 4 * channel, off_time & 0xFF)
    bus.write_byte_data(PCA9685_ADDRESS, LED0_OFF_H + 4 * channel, (off_time >> 8) & 0xFF)

def set_duty_cycle(bus, channel, percent):
    percent = max(0, min(100, percent))
    ticks = int(percent * 4095 / 100)
    set_pwm(bus, channel, ticks)

# ========================
# Servo control
# ========================
def checksum(data):
    return (~sum(data)) & 0xFF

def move_servo(ser, servo_id, position):
    """Move servo using Dynamixel-style packet with checksum."""
    pos_val = int((position / 360.0) * 4095)
    pos_l = pos_val & 0xFF
    pos_h = (pos_val >> 8) & 0xFF
    packet = [0xFF, 0xFF, servo_id, 7, 0x03, 0x2A, pos_l, pos_h, 0x00, 0x00]
    packet.append(checksum(packet[2:]))
    ser.write(bytearray(packet))
    time.sleep(0.05)

def list_serial_ports():
    return glob.glob('/dev/ttyUSB*')

def scan_servos(ser):
    found_ids = []
    for servo_id in range(1, 21):
        packet = [0xFF, 0xFF, servo_id, 2, 0x01]
        packet.append(checksum(packet[2:]))
        ser.write(bytearray(packet))
        time.sleep(0.03)
        if ser.in_waiting > 0:
            response = ser.read(ser.in_waiting)
            if len(response) >= 6 and response[0] == 0xFF and response[1] == 0xFF:
                found_ids.append(servo_id)
    return found_ids

# ========================
# ROS2 Node
# ========================
class ServoLaserNode(Node):
    def __init__(self):
        super().__init__('servo_laser_node')

        # ------------------
        # Serial setup
        # ------------------
        baud = 1000000
        ports = list_serial_ports()
        self.get_logger().info(f"Found serial ports: {ports}")
        self.port_connections = {}

        for port in ports:
            try:
                ser = serial.Serial(port, baudrate=baud, timeout=0.1)
                ids = scan_servos(ser)
                ser.close()
                if ids:
                    self.port_connections[port] = serial.Serial(port, baudrate=baud, timeout=0.1)
                    self.get_logger().info(f"Connected to port {port}, detected servos: {ids}")
            except Exception as e:
                self.get_logger().warn(f"Failed to open {port}: {e}")

        if not self.port_connections:
            self.get_logger().error("No serial ports with servos detected.")
            return

        # ------------------
        # Define which servos to control
        # ------------------
        self.servo_x_id = 2
        self.servo_y_id = 6
        self.servo_map = {self.servo_x_id: None, self.servo_y_id: None}

        # Map servo IDs to available ports
        for port, ser in self.port_connections.items():
            for sid in [self.servo_x_id, self.servo_y_id]:
                if self.servo_map[sid] is None:
                    self.servo_map[sid] = ser

        # ------------------
        # Laser setup
        # ------------------
        self.bus = SMBus(I2C_BUS_NUMBER)
        init_pca9685(self.bus)
        self.laser_channel = 0
        self.laser_power = 0.0  # percent

        # ------------------
        # Load RandomForest model
        # ------------------
        self.model = joblib.load("/home/nika/RF_Metal_Arm2.pkl")

        # ------------------
        # ROS2 Subscriptions
        # ------------------
        self.create_subscription(Float32MultiArray, 'zed/weed_centers', self.weed_callback, 10)
        self.create_subscription(Float32, 'zed/depth', self.depth_callback, 10)
        self.create_subscription(Vector3, 'zed/orientation', self.orientation_callback, 10)

        # Latest inputs
        self.latest_u = None
        self.latest_v = None
        self.latest_depth = None
        self.latest_pitch = None
        self.latest_roll = None

        self.get_logger().info("Servo + Laser control node started.")

    # ------------------------
    # ROS2 Callbacks
    # ------------------------
    def weed_callback(self, msg):
        if len(msg.data) >= 2:
            self.latest_u, self.latest_v = msg.data[0], msg.data[1]
            self.try_move()

    def depth_callback(self, msg):
        self.latest_depth = msg.data / 1000.0  # mm → m
        self.try_move()

    def orientation_callback(self, msg):
        self.latest_pitch = msg.y
        self.latest_roll = msg.z
        self.try_move()

    # ------------------------
    # Main movement logic
    # ------------------------
    def try_move(self):
        # Need all inputs
        if None in (self.latest_u, self.latest_v, self.latest_depth,
                    self.latest_pitch, self.latest_roll):
            return

        features = [[
            self.latest_u,
            self.latest_v,
            self.latest_depth,
            self.latest_pitch,
            self.latest_roll
        ]]
        theta_x, theta_y = self.model.predict(features)[0]

        # Move servos
        for sid, ser in self.servo_map.items():
            if ser:
                move_servo(ser, sid, theta_x if sid == self.servo_x_id else theta_y)

        # Laser bounding check
        if 0 <= self.latest_u <= 1280 and 0 <= self.latest_v <= 720:
            set_duty_cycle(self.bus, self.laser_channel, self.laser_power)
        else:
            set_duty_cycle(self.bus, self.laser_channel, 0.0)

        self.get_logger().info(
            f"Target ({self.latest_u:.1f}, {self.latest_v:.1f}), "
            f"Depth={self.latest_depth:.2f}m → "
            f"Servos X={theta_x:.1f}, Y={theta_y:.1f}, "
            f"Laser {self.laser_power}% ON"
        )

# ========================
# Entry point
# ========================
def main(args=None):
    rclpy.init(args=args)
    node = ServoLaserNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        set_duty_cycle(node.bus, node.laser_channel, 0.0)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

