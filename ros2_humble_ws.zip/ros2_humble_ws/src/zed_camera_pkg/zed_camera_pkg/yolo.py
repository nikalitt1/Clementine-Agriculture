import rclpy
from rclpy.node import Node
import cv2
import numpy as np
import threading
import time
from std_msgs.msg import Float32MultiArray, Float32
from geometry_msgs.msg import Vector3
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from ultralytics import YOLO
import pyzed.sl as sl
from filterpy.kalman import KalmanFilter

class ZEDYoloMotionNode(Node):
    def __init__(self):
        super().__init__('zed_yolo_motion_node')

        # Publishers
        self.image_pub = self.create_publisher(Image, 'zed/image_raw', 10)
        self.weed_pub = self.create_publisher(Float32MultiArray, 'zed/weed_centers', 10)
        self.predicted_pub = self.create_publisher(Image, 'zed/image_predicted', 10)
        self.predicted_coords_pub = self.create_publisher(Float32MultiArray, 'zed/predicted_centers', 10)
        self.orientation_pub = self.create_publisher(Vector3, 'zed/orientation', 10)
        self.depth_pub = self.create_publisher(Float32, 'zed/depth', 10)

        # CV bridge & YOLO model
        self.bridge = CvBridge()
        self.model = YOLO("/home/nika/belt3.engine")

        # ZED initialization
        self.zed = sl.Camera()
        init_params = sl.InitParameters()
        init_params.camera_resolution = sl.RESOLUTION.HD1080
        init_params.depth_mode = sl.DEPTH_MODE.PERFORMANCE
        init_params.coordinate_units = sl.UNIT.METER
        init_params.camera_fps = 60
        status = self.zed.open(init_params)
        if status != sl.ERROR_CODE.SUCCESS:
            self.get_logger().error(f"ZED failed to open: {status}")
            return

        self.camera_ready = True
        self.runtime_params = sl.RuntimeParameters()
        self.image = sl.Mat()
        self.depth = sl.Mat()
        self.sensors_data = sl.SensorsData()

        # Thread-safe frame
        self.latest_frame = None
        self.frame_lock = threading.Lock()
        self.inference_interval = 0.1
        self.last_inference_time = 0.0

        # Motion offset parameters
        self.current_offset = 0
        self.last_median_x = None

        # Weed tracking
        self.tracked_weeds = {}
        self.next_weed_id = 1
        self.max_distance = 50
        self.expire_time = 0.5

        # Per-weed Kalman filters
        self.kfs_per_weed = {}

        # Preallocated message objects
        self.pred_msg = Float32MultiArray()
        self.weed_msg = Float32MultiArray()

        # Start inference thread
        self.inference_thread = threading.Thread(target=self.run_inference_loop, daemon=True)
        self.inference_thread.start()

        # Capture timer
        self.timer = self.create_timer(1.0 / 60.0, self.capture_callback)

    def capture_callback(self):
        if self.zed.grab(self.runtime_params) != sl.ERROR_CODE.SUCCESS:
            return

        self.zed.retrieve_image(self.image, sl.VIEW.LEFT)
        frame = self.image.get_data()
        frame_bgr = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        frame_small = cv2.resize(frame_bgr, (640, 360))

        with self.frame_lock:
            self.latest_frame = frame_small.copy()

        self.image_pub.publish(self.bridge.cv2_to_imgmsg(frame_small, encoding='bgr8'))

        # Depth
        self.zed.retrieve_measure(self.depth, sl.MEASURE.DEPTH)
        depth_map = self.depth.get_data()
        valid_depth = depth_map[np.isfinite(depth_map) & (depth_map > 0)]
        depth_val = float(np.mean(valid_depth)) if valid_depth.size > 0 else 0.26
        self.depth_pub.publish(Float32(data=depth_val))

        # Orientation
        if self.zed.get_sensors_data(self.sensors_data, sl.TIME_REFERENCE.IMAGE) == sl.ERROR_CODE.SUCCESS:
            imu_data = self.sensors_data.get_imu_data()
            roll, pitch, yaw = imu_data.get_pose().get_euler_angles()
            self.orientation_pub.publish(Vector3(x=pitch, y=roll, z=yaw))

    def run_inference_loop(self):
        while rclpy.ok():
            frame = None
            with self.frame_lock:
                if self.latest_frame is not None:
                    frame = self.latest_frame
                    self.latest_frame = None

            if frame is None:
                time.sleep(0.001)
                continue

            now = time.time()
            if now - self.last_inference_time < self.inference_interval:
                time.sleep(0.001)
                continue
            self.last_inference_time = now

            results = self.model.predict(source=frame, imgsz=640, verbose=False)
            weed_centers = []

            for result in results:
                boxes = result.boxes.xyxy.cpu().numpy()
                confs = result.boxes.conf.cpu().numpy()
                mask = confs >= 0.65
                boxes = boxes[mask]

                for box in boxes:
                    x1, y1, x2, y2 = map(int, box)
                    cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
                    weed_centers.append((cx, cy))

            self.update_tracking(weed_centers)

            if weed_centers:
                self.weed_msg.data = [float(c) for p in weed_centers for c in p]
                self.weed_pub.publish(self.weed_msg)

            self.update_motion_offset()
            self.draw_and_publish(frame)

    def update_tracking(self, centers):
        now = time.time()
        expired_ids = [oid for oid, data in self.tracked_weeds.items() if now - data['last_seen'] > self.expire_time]
        for oid in expired_ids:
            del self.tracked_weeds[oid]
            if oid in self.kfs_per_weed:
                del self.kfs_per_weed[oid]

        unmatched = centers.copy()
        for cx, cy in centers:
            min_dist, best_id = float('inf'), None
            for oid, data in self.tracked_weeds.items():
                dist = np.hypot(cx - data['pos'][0], cy - data['pos'][1])
                if dist < min_dist and dist < self.max_distance:
                    min_dist, best_id = dist, oid
            if best_id is not None:
                self.tracked_weeds[best_id]['pos'] = (cx, cy)
                self.tracked_weeds[best_id]['last_seen'] = now
                unmatched.remove((cx, cy))

        for cx, cy in unmatched:
            wid = self.next_weed_id
            self.tracked_weeds[wid] = {'pos': (cx, cy), 'last_seen': now}

            # Initialize per-weed Kalman filter
            kf = KalmanFilter(dim_x=2, dim_z=1)
            kf.F = np.array([[1, 1], [0, 1]], dtype=float)
            kf.H = np.array([[1, 0]], dtype=float)
            kf.P *= 500.0
            kf.R *= 1.0
            kf.Q = np.eye(2) * 0.1
            kf.x = np.array([[cx], [0.0]], dtype=float)
            self.kfs_per_weed[wid] = kf

            self.next_weed_id += 1

    def update_motion_offset(self):
        if not self.tracked_weeds:
            self.current_offset *= 0.9
            return

        offsets = []
        for wid, data in self.tracked_weeds.items():
            kf = self.kfs_per_weed.get(wid)
            if kf is None:
                continue
            kf.predict()
            kf.update(np.array([[data['pos'][0]]]))
            velocity = float(kf.x[1, 0])
            frames_ahead = 5
            predicted_offset = max(0.0, velocity * frames_ahead * 2.0)
            offsets.append(predicted_offset)

        if offsets:
            alpha_offset = 0.2
            self.current_offset = alpha_offset * np.median(offsets) + (1 - alpha_offset) * self.current_offset
            MAX_OFFSET = 200
            self.current_offset = np.clip(self.current_offset, 0, MAX_OFFSET)

    def draw_and_publish(self, frame):
        predicted_data = []
        frame_draw = frame.copy()

        for (cx, cy), wid in [(tuple(data['pos']), oid) for oid, data in self.tracked_weeds.items()]:
            pred_cx = int(cx + self.current_offset)
            pred_cy = cy
            predicted_data.extend([float(wid), float(pred_cx), float(pred_cy)])
            cv2.putText(frame_draw, str(wid), (pred_cx, pred_cy - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            cv2.drawMarker(frame_draw, (pred_cx, pred_cy), (0, 0, 255),
                           markerType=cv2.MARKER_CROSS, markerSize=25, thickness=2)

        if predicted_data:
            self.pred_msg.data = predicted_data
            self.predicted_coords_pub.publish(self.pred_msg)
            self.predicted_pub.publish(self.bridge.cv2_to_imgmsg(frame_draw, encoding='bgr8'))
            self.get_logger().info(f"[INFERENCE] Predicted weed centers with IDs: {predicted_data}")

def main(args=None):
    rclpy.init(args=args)
    node = ZEDYoloMotionNode()
    if not getattr(node, 'camera_ready', False):
        node.destroy_node()
        rclpy.shutdown()
        return
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

