import rclpy
from rclpy.node import Node
import cv2
import numpy as np
import threading
import time
from std_msgs.msg import Float32MultiArray, Float32
from geometry_msgs.msg import Vector3
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from ultralytics import YOLO
import pyzed.sl as sl
from filterpy.kalman import KalmanFilter

class ZEDYoloMotionNode(Node):
    def __init__(self):
        super().__init__('zed_yolo_motion_node')

        # Publishers
        self.image_pub = self.create_publisher(Image, 'zed/image_raw', 10)
        self.mockweed_depth_pub = self.create_publisher(Float32MultiArray, 'zed/weed_centers', 10)
        self.predicted_pub = self.create_publisher(Image, 'zed/image_predicted', 10)
        self.predicted_coords_pub = self.create_publisher(Float32MultiArray, 'zed/predicted_centers', 10)
        self.orientation_pub = self.create_publisher(Vector3, 'zed/orientation', 10)
        self.depth_pub = self.create_publisher(Float32, 'zed/depth', 10)

        # CV bridge & YOLO model
        self.bridge = CvBridge()
        model_path = "/home/nika/belt2.engine"
        self.model = YOLO(model_path)
        self.class_names = ["crop", "weed"]

        # ZED initialization
        self.zed = sl.Camera()
        init_params = sl.InitParameters()
        init_params.camera_resolution = sl.RESOLUTION.HD1080
        init_params.depth_mode = sl.DEPTH_MODE.PERFORMANCE
        init_params.coordinate_units = sl.UNIT.METER
        init_params.camera_fps = 60
        status = self.zed.open(init_params)
        if status != sl.ERROR_CODE.SUCCESS:
            self.get_logger().error(f"ZED failed to open: {status}")
            return

        self.camera_ready = True
        self.runtime_params = sl.RuntimeParameters()
        self.image = sl.Mat()
        self.depth = sl.Mat()
        self.sensors_data = sl.SensorsData()  # preallocate

        # Thread-safe frame
        self.latest_frame = None
        self.frame_lock = threading.Lock()
        self.inference_interval = 0.1
        self.last_inference_time = 0.0

        # Kalman filter for motion detection
        self.motion_kf = KalmanFilter(dim_x=2, dim_z=1)
        self.motion_kf.F = np.array([[1, 1], [0, 1]], dtype=float)
        self.motion_kf.H = np.array([[1, 0]], dtype=float)
        self.motion_kf.P *= 500.0
        self.motion_kf.R *= 1.0
        self.motion_kf.Q = np.eye(2) * 0.1
        self.motion_kf.x = np.array([[0.0], [0.0]], dtype=float)

        # Dynamic offset parameters
        self.base_offset = 45
        self.offset_increment = 10
        self.current_offset = 0
        self.previous_velocity = 0.0
        self.max_jump = 200
        self.last_median_x = None

        # --- Weed tracking ---
        self.tracked_weeds = {}
        self.next_weed_id = 1
        self.max_distance = 50
        self.expire_time = 0.5

        # --- Crop tracking ---
        self.tracked_crops = {}
        self.next_crop_id = 1
        self.max_distance_crop = 50

        # Motion tracking state
        self.velocity_update_counter = 0
        self.filtered_velocity = 0.0

        # Preallocated message objects
        self.pred_msg = Float32MultiArray()
        self.mockweed_msg = Float32MultiArray()

        # Start inference thread
        self.inference_thread = threading.Thread(target=self.run_inference_loop, daemon=True)
        self.inference_thread.start()

        # Capture timer
        self.timer = self.create_timer(1.0 / 60.0, self.capture_callback)

    # ------------------------------
    # Capture callback
    # ------------------------------
    def capture_callback(self):
        if self.zed.grab(self.runtime_params) != sl.ERROR_CODE.SUCCESS:
            return

        self.zed.retrieve_image(self.image, sl.VIEW.LEFT)
        frame = self.image.get_data()
        frame_bgr = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        frame_small = cv2.resize(frame_bgr, (640, 360))

        with self.frame_lock:
            self.latest_frame = frame_small.copy()

        self.image_pub.publish(self.bridge.cv2_to_imgmsg(frame_small, encoding='bgr8'))

        # Depth
        self.zed.retrieve_measure(self.depth, sl.MEASURE.DEPTH)
        depth_map = self.depth.get_data()
        valid_depth = depth_map[np.isfinite(depth_map) & (depth_map > 0)]
        depth_val = float(np.mean(valid_depth)) if valid_depth.size > 0 else 0.26
        self.depth_pub.publish(Float32(data=depth_val))

        # Orientation
        if self.zed.get_sensors_data(self.sensors_data, sl.TIME_REFERENCE.IMAGE) == sl.ERROR_CODE.SUCCESS:
            imu_data = self.sensors_data.get_imu_data()
            roll, pitch, yaw = imu_data.get_pose().get_euler_angles()
            self.orientation_pub.publish(Vector3(x=pitch, y=roll, z=yaw))

    # ------------------------------
    # Inference loop
    # ------------------------------
    def run_inference_loop(self):
        while rclpy.ok():
            frame = None
            with self.frame_lock:
                if self.latest_frame is not None:
                    frame = self.latest_frame
                    self.latest_frame = None

            if frame is None:
                time.sleep(0.001)
                continue

            now = time.time()
            if now - self.last_inference_time < self.inference_interval:
                time.sleep(0.001)
                continue

            self.last_inference_time = now
            results = self.model.predict(source=frame, imgsz=640, verbose=False)

            weed_centers, crop_centers = [], []

            for result in results:
                boxes = result.boxes.xyxy.cpu().numpy()
                confs = result.boxes.conf.cpu().numpy()
                classes = result.boxes.cls.cpu().numpy()
                mask = confs >= 0.7
                boxes, classes = boxes[mask], classes[mask]

                for box, cls_id in zip(boxes, classes):
                    x1, y1, x2, y2 = map(int, box)
                    cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
                    if self.class_names[int(cls_id)] == "weed":
                        weed_centers.append((cx, cy))
                    elif self.class_names[int(cls_id)] == "crop":
                        crop_centers.append((cx, cy))

            self.update_tracking(weed_centers, self.tracked_weeds, self.max_distance, 'weed')
            self.update_tracking(crop_centers, self.tracked_crops, self.max_distance_crop, 'crop')

            # Publish raw weed centers
            if weed_centers:
                self.mockweed_msg.data = [float(c) for p in weed_centers for c in p]
                self.mockweed_depth_pub.publish(self.mockweed_msg)

            # Motion offset logic for weeds
            self.update_motion_offset(weed_centers)

            # Draw and publish
            self.draw_and_publish(frame, weed_centers, crop_centers)

    # ------------------------------
    # Object tracking helper
    # ------------------------------
    def update_tracking(self, centers, tracked_dict, max_distance, obj_type):
        now = time.time()
        # Remove expired
        expired_ids = [oid for oid, data in tracked_dict.items() if now - data['last_seen'] > self.expire_time]
        for oid in expired_ids:
            del tracked_dict[oid]

        unmatched = centers.copy()
        for cx, cy in centers:
            min_dist, best_id = float('inf'), None
            for oid, data in tracked_dict.items():
                dist = np.hypot(cx - data['pos'][0], cy - data['pos'][1])
                if dist < min_dist and dist < max_distance:
                    min_dist, best_id = dist, oid
            if best_id is not None:
                tracked_dict[best_id]['pos'] = (cx, cy)
                tracked_dict[best_id]['last_seen'] = now
                unmatched.remove((cx, cy))
        # Add new
        next_id = self.next_weed_id if obj_type == 'weed' else self.next_crop_id
        for cx, cy in unmatched:
            tracked_dict[next_id] = {'pos': (cx, cy), 'last_seen': now}
            next_id += 1
        if obj_type == 'weed':
            self.next_weed_id = next_id
        else:
            self.next_crop_id = next_id

    # ------------------------------
    # Motion offset helper
    # ------------------------------
    def update_motion_offset(self, weed_centers):
        if not weed_centers:
            self.current_offset *= 0.9
            if self.current_offset < 1:
                self.current_offset = 0
            self.previous_velocity = 0.0
            return

        median_x = np.median(np.array(weed_centers)[:, 0])
        if self.last_median_x is not None:
            delta = median_x - self.last_median_x
            median_x = self.last_median_x + np.clip(delta, -self.max_jump, self.max_jump)
        self.last_median_x = median_x

        self.velocity_update_counter += 1
        if self.velocity_update_counter < 3:
            return

        self.motion_kf.predict()
        self.motion_kf.update(np.array([[median_x]]))
        raw_velocity = float(self.motion_kf.x[1, 0])
        alpha = 0.1
        self.filtered_velocity = alpha * raw_velocity + (1 - alpha) * self.filtered_velocity

        if abs(self.filtered_velocity) > 0.7:
            if self.filtered_velocity > self.previous_velocity:
                self.current_offset += self.offset_increment
            else:
                self.current_offset = max(self.base_offset, self.current_offset * 0.83)
        else:
            self.current_offset *= 0.9
            if self.current_offset < 1:
                self.current_offset = 0

        self.previous_velocity = self.filtered_velocity
        self.velocity_update_counter = 0

    # ------------------------------
    # Drawing helper
    # ------------------------------
    def draw_and_publish(self, frame, weed_centers, crop_centers):
        predicted_data = []
        frame_draw = frame.copy()

        for (cx, cy), wid in [(tuple(data['pos']), oid) for oid, data in self.tracked_weeds.items()]:
            pred_cx = int(cx + self.current_offset)
            pred_cy = cy
            predicted_data.extend([float(wid), float(pred_cx), float(pred_cy)])
            cv2.putText(frame_draw, str(wid), (pred_cx, pred_cy - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            cv2.drawMarker(frame_draw, (pred_cx, pred_cy), (0, 0, 255),
                           markerType=cv2.MARKER_CROSS, markerSize=25, thickness=2)

        for (cx, cy), cid in [(tuple(data['pos']), oid) for oid, data in self.tracked_crops.items()]:
            cv2.putText(frame_draw, str(cid), (cx, cy - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            cv2.circle(frame_draw, (cx, cy), 20, (0, 255, 0), 2)

        if predicted_data:
            self.pred_msg.data = predicted_data
            self.predicted_coords_pub.publish(self.pred_msg)
            self.predicted_pub.publish(self.bridge.cv2_to_imgmsg(frame_draw, encoding='bgr8'))
            self.get_logger().info(f"[INFERENCE] Predicted weed centers with IDs: {predicted_data}")


def main(args=None):
    rclpy.init(args=args)
    node = ZEDYoloMotionNode()
    if not getattr(node, 'camera_ready', False):
        node.destroy_node()
        rclpy.shutdown()
        return
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

