import rclpy
from rclpy.node import Node
import cv2
import numpy as np
import threading
import time
from std_msgs.msg import Float32MultiArray, Float32
from geometry_msgs.msg import Vector3
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from ultralytics import YOLO
import pyzed.sl as sl
from filterpy.kalman import KalmanFilter


class ZEDYoloMotionNode(Node):
    def __init__(self):
        super().__init__('zed_yolo_motion_node')

        # Publishers
        self.image_pub = self.create_publisher(Image, 'zed/image_raw', 10)
        self.mockweed_depth_pub = self.create_publisher(Float32MultiArray, 'zed/weed_centers', 10)
        self.predicted_pub = self.create_publisher(Image, 'zed/image_predicted', 10)
        self.predicted_coords_pub = self.create_publisher(Float32MultiArray, 'zed/predicted_centers', 10)
        self.orientation_pub = self.create_publisher(Vector3, 'zed/orientation', 10)
        self.depth_pub = self.create_publisher(Float32, 'zed/depth', 10)

        # CV bridge & YOLO model
        self.bridge = CvBridge()
        model_path = "/home/nika/belt2.engine"
        self.model = YOLO(model_path)
        self.class_names = ["crop", "weed"]

        # ZED initialization
        self.zed = sl.Camera()
        init_params = sl.InitParameters()
        init_params.camera_resolution = sl.RESOLUTION.HD1080  # Keep full resolution for ZED
        init_params.depth_mode = sl.DEPTH_MODE.PERFORMANCE
        init_params.coordinate_units = sl.UNIT.METER
        init_params.camera_fps = 30

        status = self.zed.open(init_params)
        if status != sl.ERROR_CODE.SUCCESS:
            self.get_logger().error(f"ZED failed to open: {status}")
            return
        self.camera_ready = True

        self.runtime_params = sl.RuntimeParameters()
        self.image = sl.Mat()
        self.depth = sl.Mat()

        # Thread-safe frame
        self.latest_frame = None
        self.frame_lock = threading.Lock()
        self.inference_interval = 0.1
        self.last_inference_time = 0.0

        # Kalman filter for motion detection
        self.motion_kf = KalmanFilter(dim_x=2, dim_z=1)
        self.motion_kf.F = np.array([[1, 1], [0, 1]], dtype=float)
        self.motion_kf.H = np.array([[1, 0]], dtype=float)
        self.motion_kf.P *= 500.0
        self.motion_kf.R *= 5.0
        self.motion_kf.Q = np.eye(2) * 0.1
        self.motion_kf.x = np.array([[0.0], [0.0]], dtype=float)

        self.hard_offset = 47  # pixels offset if motion detected

        # Start inference thread
        self.inference_thread = threading.Thread(target=self.run_inference_loop, daemon=True)
        self.inference_thread.start()

        # Capture timer at 30 FPS
        self.timer = self.create_timer(1.0 / 30.0, self.capture_callback)

    def capture_callback(self):
        if self.zed.grab(self.runtime_params) != sl.ERROR_CODE.SUCCESS:
            return

        # Retrieve left camera image
        self.zed.retrieve_image(self.image, sl.VIEW.LEFT)
        frame = self.image.get_data()
        frame_bgr = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)

        # Scale down to 640 width for ROS publishing
        height, width = frame_bgr.shape[:2]
        scale = 640 / width
        frame_small = cv2.resize(frame_bgr, (640, int(height * scale)))

        with self.frame_lock:
            self.latest_frame = frame_small.copy()

        # Publish scaled image immediately
        self.image_pub.publish(self.bridge.cv2_to_imgmsg(frame_small, encoding='bgr8'))

        # === Average depth across frame ===
        self.zed.retrieve_measure(self.depth, sl.MEASURE.DEPTH)
        depth_map = self.depth.get_data()
        depth_val = 0.26  # default

        try:
            valid_depth = depth_map[np.isfinite(depth_map)]
            valid_depth = valid_depth[valid_depth > 0]
            if valid_depth.size > 0:
                depth_val = float(np.mean(valid_depth))
        except Exception as e:
            self.get_logger().warn(f"Failed to process depth map: {e}")

        self.depth_pub.publish(Float32(data=depth_val))

        # === Orientation (pitch, roll, yaw) ===
        pitch, roll, yaw = None, None, None
        sensors_data = sl.SensorsData()
        if self.zed.get_sensors_data(sensors_data, sl.TIME_REFERENCE.IMAGE) == sl.ERROR_CODE.SUCCESS:
            imu_data = sensors_data.get_imu_data()
            roll, pitch, yaw = imu_data.get_pose().get_euler_angles()
            orientation_msg = Vector3(x=pitch, y=roll, z=yaw)
            self.orientation_pub.publish(orientation_msg)

        self.get_logger().info(f"[CAPTURE] Depth={depth_val:.2f} m, Pitch={pitch}, Roll={roll}, Yaw={yaw}")

    def run_inference_loop(self):
        while rclpy.ok():
            frame = None
            with self.frame_lock:
                if self.latest_frame is not None:
                    frame = self.latest_frame
                    self.latest_frame = None
            if frame is None:
                time.sleep(0.001)
                continue

            now = time.time()
            if now - self.last_inference_time < self.inference_interval:
                time.sleep(0.001)
                continue
            self.last_inference_time = now

            # YOLO detection
            results = self.model.predict(source=frame, imgsz=640, verbose=False)
            weed_centers = []
            for result in results:
                boxes = result.boxes.xyxy.cpu().numpy()
                confs = result.boxes.conf.cpu().numpy()
                classes = result.boxes.cls.cpu().numpy()
                for box, conf, cls_id in zip(boxes, confs, classes):
                    if conf < 0.5:
                        continue
                    x1, y1, x2, y2 = map(int, box)
                    if self.class_names[int(cls_id)] == "weed":
                        cx = (x1 + x2) // 2
                        cy = (y1 + y2) // 2
                        weed_centers.append((cx, cy))
                        
                    

            # Publish raw weed centers
            if weed_centers:
                msg = Float32MultiArray()
                msg.data = [float(c) for p in weed_centers for c in p]
                self.mockweed_depth_pub.publish(msg)

            # Motion detection
            motion_detected = False
            if weed_centers:
                median_x = np.median([c[0] for c in weed_centers])
                self.motion_kf.predict()
                self.motion_kf.update(np.array([[median_x]]))
                velocity = abs(float(self.motion_kf.x[1, 0]))
                motion_detected = velocity > 0.5

            # Draw red crosshairs & publish predicted coordinates exactly matching them
            predicted_data = []
            frame_draw = frame.copy()  # Use separate copy for drawing
            for cx, cy in weed_centers:
                pred_cx = cx + self.hard_offset if motion_detected else cx
                pred_cy = cy
                predicted_data.extend([float(pred_cx), float(pred_cy)])
                cv2.drawMarker(frame_draw, (pred_cx, pred_cy),
                               (0, 0, 255), markerType=cv2.MARKER_CROSS,
                               markerSize=25, thickness=2)

            # Publish predicted coordinates & image
            pred_msg = Float32MultiArray()
            pred_msg.data = predicted_data
            self.predicted_coords_pub.publish(pred_msg)
            self.predicted_pub.publish(self.bridge.cv2_to_imgmsg(frame_draw, encoding='bgr8'))

            if predicted_data:
                self.get_logger().info(f"[INFERENCE] Predicted centers: {predicted_data}")


def main(args=None):
    rclpy.init(args=args)
    node = ZEDYoloMotionNode()
    if not getattr(node, 'camera_ready', False):
        node.destroy_node()
        rclpy.shutdown()
        return
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

