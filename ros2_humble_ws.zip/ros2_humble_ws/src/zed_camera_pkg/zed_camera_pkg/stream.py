import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from flask import Flask, Response
import threading
import cv2
import time

app = Flask(__name__)

# Shared frame buffer and lock
latest_frame = None
frame_lock = threading.Lock()

bridge = CvBridge()

class VideoListener(Node):
    def __init__(self):
        super().__init__('video_listener')
        self.subscription = self.create_subscription(
            Image,
            '/zed/image_raw',
            self.listener_callback,
            10
        )

    def listener_callback(self, msg):
        global latest_frame
        try:
            cv_image = bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

            # ✅ Resize frame to reduce latency and bandwidth
            resized_image = cv2.resize(cv_image, (640, 360))

            # ✅ Encode with reduced JPEG quality (80 instead of 95+)
            ret, jpeg = cv2.imencode('.jpg', resized_image, [cv2.IMWRITE_JPEG_QUALITY, 80])
            if ret:
                with frame_lock:
                    latest_frame = jpeg.tobytes()
        except Exception as e:
            self.get_logger().error(f'Failed to convert image: {e}')


def generate_frames():
    global latest_frame
    while True:
        with frame_lock:
            frame = latest_frame
        if frame is not None:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        # ✅ Short sleep prevents overload and helps reduce latency
        time.sleep(0.01)


@app.route('/')
def index():
    return '<html><body><h1>ZED ROS2 Stream</h1><img src="/video_feed"></body></html>'


@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')


def start_flask():
    app.run(host='0.0.0.0', port=5000, threaded=True)


def main():
    rclpy.init()
    node = VideoListener()

    flask_thread = threading.Thread(target=start_flask, daemon=True)
    flask_thread.start()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
